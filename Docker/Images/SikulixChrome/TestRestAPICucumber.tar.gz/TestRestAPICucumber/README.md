# Rest_API_test with cucumber and maven

## This project is to test endpoints of an API REST (Automation API and Levana of Datio Platform)

## Requirements: JAVA (>=8), mvn(3.3.9), Intellij and connection to Bank VPN.


## Steps:

- Do a fork of the project

- Clone the fork in your local

 ```
 git clone git@github.com:<user>/QA.git

 ```

 - To run all Levana tests with maven for example, open a terminal and on the root of the project run :

```
mvn -DENV_URL=https://ip -DAUTH="my_authentication" -DUSER=my_user -Dcucumber.options="--tags @Levana" verify

```

- If you are using Intellij, open the project cloned, click on the RUN > Edit configurations button. In the window opened, select Maven > Maven Cucumber, then you will see several tabs, select Paramaters tab and paste the following:

```
-DENV_URL=https://ip -DAUTH="my_authentication" -DUSER=my_user -Dcucumber.options="--tags @Levana" verify
```

on the command line box. 
