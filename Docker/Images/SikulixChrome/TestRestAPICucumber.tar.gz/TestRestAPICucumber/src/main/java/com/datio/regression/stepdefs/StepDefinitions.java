package com.datio.regression.stepdefs;

import com.datio.regression.modules.*;
import com.datio.regression.pageObjects.*;
import com.datio.regression.util.SSLUtilities;
import com.datio.regression.util.ThreadProperty;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.sikuli.script.FindFailed;
import org.testng.Assert;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import java.net.MalformedURLException;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import static com.datio.regression.pageObjects.ModifyHeadersSikulix.*;

public class StepDefinitions {

    private URL url;
    private URL urlSeleniumHub;
    private HttpsURLConnection con;
    private int responseCode;
    private StringBuilder response;
    private StringBuilder content;
    private URL urlBase;
    private String status;
    private String responseJsonBody;
    private ObjectNode node;
    
    private static final Logger LOGGER = Logger.getLogger( StepDefinitions.class.getName() );
    RemoteWebDriver driver;
    WebDriver dr;

    @Given("A connection \"([^\"]*)\"$")
    public void connection(String urlbase) throws MalformedURLException {
        urlBase = new URL(urlbase);
        LOGGER.log( Level.INFO, "successful connection" );
    }

    @When("User makes a \"([^\"]*)\" request to \"([^\"]*)\"(?: with \"([^\"]*)\"$)?") //'with data ""' is optional and job_size
    public void request(String request, String pathname, String file) throws IOException {

        //Here  we avoid certificate of connection
        SSLUtilities.trustAllHostnames();
        SSLUtilities.trustAllHttpsCertificates();

        // concatenate urlBase with pathname
        this.url = new URL(urlBase.getProtocol(), urlBase.getHost(),urlBase.getPort(), pathname);
        this.con = (HttpsURLConnection) url.openConnection();

        //Assing headers
        ThreadProperty.getHeaders().forEach((key) -> {
            con.setRequestProperty(key, ThreadProperty.getHeader(key));
        });

        switch (request) {
            case "POST":
                con.setRequestMethod("POST");
                con.setUseCaches(false);
                con.setDoOutput(true);
                if (file != null){
                    BufferedReader in = new BufferedReader(
                            new FileReader("src/test/resources/" + file));
                    String inputLine;
                    this.content = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        content.append(inputLine);
                    }
                    con.setRequestProperty("Content-Type", "application/json");
                    
                    OutputStreamWriter wr = new OutputStreamWriter(
                            con.getOutputStream());
                    wr.write(content.toString());
                    wr.close();
                    
                    BufferedReader in2 = new BufferedReader(
                            new InputStreamReader(con.getInputStream()));
                    String inputLine2;
                    this.response = new StringBuilder();
                    while ((inputLine2 = in2.readLine()) != null) {
                        response.append(inputLine2);
                    }
                    
                    this.responseCode = con.getResponseCode();
                    
                }else{
                    
                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(con.getInputStream()));
                    String inputLine;
                    this.response = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    con.setRequestProperty("Content-Type", "application/json");
                    this.responseCode = con.getResponseCode();
                }   LOGGER.log( Level.INFO, request + " request" );
                break;
            case "PUT":
                {
                    BufferedReader in = new BufferedReader(
                            new FileReader("src/test/resources/" + file));
                    String inputLine;
                    this.content = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        content.append(inputLine);
                    }       con.setRequestMethod("PUT");
                    con.setRequestProperty("Content-Type", "application/json");
                    con.setUseCaches(false);
                    con.setDoOutput(true);
                    // Send request
                    OutputStreamWriter wr = new OutputStreamWriter(
                            con.getOutputStream());
                    wr.write(content.toString());
                    wr.close();
                    BufferedReader in2 = new BufferedReader(
                            new InputStreamReader(con.getInputStream()));
                    String inputLine2;
                    this.response = new StringBuilder();
                    while ((inputLine2 = in2.readLine()) != null) {
                        this.response.append(inputLine2);
                    }       this.responseCode = con.getResponseCode();
                    LOGGER.log( Level.INFO, request + " request" );
                    break;
                }
            case "GET":
                {
                    con.setRequestMethod("GET");
                    con.setRequestProperty("Content-Type", "application/json");
                    this.responseCode = con.getResponseCode();
                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(con.getInputStream()));
                    String inputLine;
                    this.response = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        this.response.append(inputLine);
                    }   LOGGER.log( Level.INFO, request + " request" );
                    break;
                }
            case "DELETE":
                con.setRequestMethod("DELETE");
                con.setDoOutput(true);
                this.responseCode = con.getResponseCode();
                this.response = null;
                LOGGER.log( Level.INFO, request + " request" );
                break;
            default:
                break;
        }

        this.responseJsonBody = (this.response == null) ? "{}" : this.response.toString();
        LOGGER.info(responseJsonBody);
    }

    @When("^User waits (\\d+) seconds")
    public void waitResponse(int seconds) throws InterruptedException {

        LOGGER.log(Level.INFO, "Wait {0} seconds", seconds);
        TimeUnit.SECONDS.sleep(seconds);
    }

    @Then("The code response is (\\d+)$")
    public void codeResponse(int code) throws IOException, ProcessingException {

        LOGGER.log(Level.INFO, "Response code: {0}", responseCode);
        Assert.assertEquals(responseCode,code, "Responses code are not matching");
    }

    @Then("^The status is \"([^\"]*)\"$") //this step is just valid for a GET (RUN) AND A POST(RUN)
    public void responseStatus(String message) throws IOException {

        this.node = new ObjectMapper().readValue(responseJsonBody, ObjectNode.class);
        //LOGGER.log( Level.INFO, String.valueOf(node)+"gg");

        if (node.has("data")){
            this.status= String.valueOf(node.get("data").get("status").get("id").textValue());

            LOGGER.log(Level.INFO, "status: {0}", status);
            Assert.assertEquals(status,message,"the status is incorrect");

        }else if (node.has("process")){
            this.status=String.valueOf(node.get("status").textValue());

            LOGGER.log(Level.INFO, "status: {0}", status);
            Assert.assertEquals(status,message,"the status is incorrect");
        }
    }

    @When("^\"([^\"]*)\" is stored as \"([^\"]*)\"$")
    public void jsonFieldIsStoredAs(String param, String env) throws Throwable {

        this.node = new ObjectMapper().readValue(responseJsonBody, ObjectNode.class);

        if (node.has("data")){
            ThreadProperty.set(env, String.valueOf(node.get("data").get(param).textValue()));
        }else if(node.has("process")){
            ThreadProperty.set(env, String.valueOf(node.get(param).textValue()));
        }
    }

    @Given("^Header \"([^\"]*)\" is set to value \"([^\"]*)\"$")
    public void header(String header, String value) throws MalformedURLException {

        ThreadProperty.setHeader(header, value);
        LOGGER.info("header right");
    }

    @And("^The \"([^\"]*)\" is \"([^\"]*)\"$")
    public void checkValue(String value, String result) throws IOException {

        LOGGER.log(Level.INFO, "internal status: {0}", value);
        Assert.assertEquals(value,result,"the internal status is incorrect");
    }


    @When("^User opens the Browser$")
    public void startUpBrowser() throws Throwable {
        driver = Hooks.driver;
        dr = driver;
    }

    @Then("^The user configures the header$")
    public void setUpModifyHeader() throws Throwable {
        driver.get("chrome-extension://innpjfdalfhpcoinfnehdnbkglpmogdi/options.html");
        ThreadProperty.getHeaders().stream().map((key) -> {
            PageFactory.initElements( dr , ModifyHeaders.class );
            return key;
        }).forEachOrdered((key) -> {
            AddHeader.Execute( driver , key , ThreadProperty.getHeader(key) );
        });
    }

    @When("^User enters the URL with endpoint \"([^\"]*)\" in the Browser$")
    public void getSite(String endPoint) throws Throwable{
        driver.get(urlBase.toString() + endPoint);
    }

    @Then("^The browser shows the element with id \"([^\"]*)\" and with the text \"([^\"]*)\"$")
    public void browserShowElement( String elementId , String message) throws Throwable {
        Assert.assertEquals(driver.findElement(By.id(elementId)).isDisplayed() , 
                true , "The element with id "+ elementId
                + " is not visible on the page");
    }

    @When("^User selects \"Start My Server\"$")
    public void startServer() throws Throwable {
        PageFactory.initElements(dr, Intelligence.class );
        Thread.sleep(10000);
        ActionsOnIntelligence.login();
    }

    @Then("^User waits for element with Id \"([^\"]*)\" is visible$")
    public void waitElementById(String id) throws Throwable {
        Tools.waitForId( driver, id );
    }

    @Then("^User waits for iframe \"([^\"]*)\" and element \"([^\"]*)\" DCOS load$")
    public void waitIframeLoad( String iframe , String id) throws Throwable {
        Thread.sleep(1000);
        Tools.waitForId( driver , iframe , 5);
        driver.switchTo().frame( iframe );
        Tools.waitForId( driver ,id , 5);
        Assert.assertEquals( driver.findElement(By.id(id)).isDisplayed() , true
                , "The element with Id " +  id + " is not visible on the page");
    }

    @Given("^A user DCOS with username \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void dataLoginDcos( String user , String passwd ) throws Throwable {
        ThreadProperty.set("user_dcos" , user);
        ThreadProperty.set("passwd_decos" , passwd);
    }

    @When("^User makes login in DCOS$")
    public void loginDcos() throws Throwable {
        PageFactory.initElements( dr , Dcos.class);
        ActionsOnDcos.login( driver , ThreadProperty.get("user_dcos") , 
                ThreadProperty.get("passwd_decos"));
    }

    @And("^User logout from DCOS$")
    public void logOutDcos() throws Throwable {
        ActionsOnDcos.logOut( driver );
    }

    @And("^User selects the Services option$")
    public void selectServices() throws Throwable {
        ActionsOnDcos.selectServices();
    }

    @And("^User selects folder analytic of path \"([^\"]*)\"$")
    public void selectFolder(String path) throws Throwable {
        ActionsOnDcos.selectFolder(path);
    }

    @Then("^User checks the status of the user's container \"([^\"]*)\"$")
    public void checkStatusContainer(String username) throws Throwable {
        Assert.assertEquals( ActionsOnDcos.isContainerPresent( driver, username ) , true ,
                "The Container is not present");
        Assert.assertEquals( ActionsOnDcos.checkStatusContainer( driver , username ) , true ,
                "The status container is not Running");
    }

    @And("^User go to intelligence \"([^\"]*)\" and logout$")
    public void logoutIntelligence(String pathIntelligence) throws InterruptedException{
        driver.get(urlBase.toString() +pathIntelligence);
        Thread.sleep(1000);
        ActionsOnIntelligence.logout();
    }



    @Then("^The user configures the header sikulix$")
    public void setUpModifyHeaderSikulix() throws Throwable {
        driver.get("chrome-extension://innpjfdalfhpcoinfnehdnbkglpmogdi/options.html");
        Thread.sleep(2000);
        ThreadProperty.getHeaders().stream().map((key) -> {
            return key;
        }).forEachOrdered((key) -> {
            try {
                ModifyHeadersSikulix.setHeader( driver , key , ThreadProperty.getHeader(key) );
            } catch (FindFailed findFailed) {
                findFailed.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        Thread.sleep(14000);
    }



}