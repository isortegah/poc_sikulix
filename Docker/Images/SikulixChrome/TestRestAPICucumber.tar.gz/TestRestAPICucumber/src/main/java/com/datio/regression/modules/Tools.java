package com.datio.regression.modules;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Tools {
    
    public static void waitForId(RemoteWebDriver driver , String id){
        WebDriverWait waiter = new WebDriverWait( driver , 15 , 500);
        waiter.until(ExpectedConditions.elementToBeClickable(By.id(id)));
    }

    public static void waitForId(RemoteWebDriver driver , String id , int seconds){
        WebDriverWait waiter = new WebDriverWait( driver , seconds , 500);
        waiter.until(ExpectedConditions.elementToBeClickable(By.id(id)));
    }

}
