package com.datio.regression.pageObjects;


import org.openqa.selenium.WebDriver;
import org.sikuli.script.*;

/**
 * @author ISORTEGAH
 */
public class ModifyHeadersSikulix {
    private static Screen screen = null;
    private static String modifyHeadersStartImage = "start.png";
    private static String modifyHeadersAddHeaderImage = "addHeader.png";
    private static String modifyHeaderActionSelectImage = "actionSelect.png";
    private static String modifyHeadersOptionAddImage = "optionAdd.png";
    private static String modifyHeadersHeaderNameImage = "headerName.png";
    private static String modifyHeadersHeaderValueImage = "headerValue.png";
    private static String modifyHeadersHeaderSaveHeader = "saveHeader.png";
    private static String modifyHeadersHeaderEnableHeader = "enableHeader.png";


    public static void setHeader(WebDriver driver , String header , String user) throws FindFailed, InterruptedException {
        screen = TestScreen.getInstance();
        // Click en botón Start:
        Pattern modifyHeadersStart = new Pattern(modifyHeadersStartImage);
        modifyHeadersStart = modifyHeadersStart.similar((float) 0.49);
        screen.find(modifyHeadersStart).click();
        Pattern modifyHeadersAddHeader = new Pattern(modifyHeadersAddHeaderImage).similar((float) 0.49);
        screen.find(modifyHeadersAddHeader).click();
        screen.find(
                new Pattern(modifyHeaderActionSelectImage)
                        .similar((float) 0.49)).click();
        screen.find(
                new Pattern(modifyHeadersOptionAddImage)
                        .similar((float) 0.60)).click();

        //Operación para agregar nombre del Header
        Region inputHeaderName = screen.find(new Pattern(modifyHeadersHeaderNameImage)
                .similar((float) 0.60));
        inputHeaderName.getBottomLeft().move( inputHeaderName.getBottomRight().getX()-20 ,
                    inputHeaderName.getBottomRight().getY()-20).click();
        screen.find(
                new Pattern(modifyHeadersHeaderNameImage)
                        .similar((float)0.60)).type(header);


        Region inputHeaderValue = screen.find(new Pattern(modifyHeadersHeaderValueImage)
                .similar((float)0.60));
        inputHeaderValue.getBottomRight().move(inputHeaderValue.getBottomRight().getX()-20 ,
                inputHeaderValue.getBottomRight().getY()-20).click();
        screen.find(
                new Pattern(modifyHeadersHeaderValueImage)
                        .similar((float)0.60)).type(user);

        screen.find(
                new Pattern(modifyHeadersHeaderSaveHeader)
                        .similar((float) 0.60)).click();
        screen.find(
                new Pattern(modifyHeadersHeaderEnableHeader)
                        .similar((float) 0.99)).click();
    }
}
