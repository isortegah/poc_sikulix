package com.datio.regression.pageObjects;

import org.openqa.selenium.WebDriver;

/**
 *
 * @author ISORTEGAH
 */
public abstract class BaseClass {

    private static WebDriver driver;

    public BaseClass(WebDriver driver) {
        BaseClass.driver = driver;
    }

    
}
