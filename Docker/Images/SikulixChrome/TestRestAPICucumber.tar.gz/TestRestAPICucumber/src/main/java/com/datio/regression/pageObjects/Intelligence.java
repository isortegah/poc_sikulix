/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.datio.regression.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 *
 * @author isortega
 */
public class Intelligence extends BaseClass{

    public Intelligence(WebDriver driver) {
        super(driver);
    }

    @FindBy(how=How.ID , using = "start")
    public static WebElement btnStart;   
    
    @FindBy(how=How.ID , using = "logout")
    public static WebElement btnLogout;
}
