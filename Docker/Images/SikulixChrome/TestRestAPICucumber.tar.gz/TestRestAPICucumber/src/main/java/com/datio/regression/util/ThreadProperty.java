package com.datio.regression.util;

import java.util.Properties;
import java.util.Set;


public final class ThreadProperty {
    private static final ThreadLocal<Properties> PROPS = new ThreadLocal<Properties>() {
        protected Properties initialValue() {
            return new Properties();
        }
    };
    private static final ThreadLocal<Properties> HEADERS = new ThreadLocal<Properties>() {
        protected Properties initialValue() {
            return new Properties();
        }
    };

    /**
     * Default Constructor.
     */
    private ThreadProperty() {
    }
    /**
     * Set a string to share in other class.
     *
     * @param key
     * @param value
     */
    public static void set(String key, String value) {
        PROPS.get().setProperty(key, value);
    }
    /**
     * Get a property shared.
     *
     * @param key
     * @return String
     */
    public static String get(String key) {
        return PROPS.get().getProperty(key);
    }

    /**
     * Set a string to share in other class.
     *
     * @param key
     * @param value
     */
    public static void setHeader(String key, String value) {
        HEADERS.get().setProperty(key, value);
    }
    /**
     * Get a property shared.
     *
     * @param key
     * @return String
     */
    public static String getHeader(String key) {
        return HEADERS.get().getProperty(key);
    }

    /**
     * Get a property shared.
     *
     * @param key
     * @return String
     */
    public static Set<String> getHeaders() {
        return HEADERS.get().stringPropertyNames();}

}
