package com.datio.regression.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ModifyHeaders extends BaseClass{
    
    @FindBy(how=How.NAME, using="name")
    public static WebElement inputName;
    
    @FindBy(how=How.NAME, using="value")
    public static WebElement inputValue;
    
    @FindBy(how=How.ID, using="btn_enable_1")
    public static WebElement enableHeader;
    
    @FindBy(how=How.ID, using="action_1")
    public static WebElement actionDropDown;
    
    @FindBy(how=How.ID, using="btn_start")
    public static WebElement btnStart;
    
    @FindBy(how=How.ID, using="btn_add_new")
    public static WebElement btnNew;
    
    @FindBy(how=How.ID, using="btn_save_1")
    public static WebElement btnSave;
    
    public ModifyHeaders(WebDriver driver) {
        super(driver);
    }
}
