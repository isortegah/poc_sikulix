package com.datio.regression.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 *
 * @author ISORTEGAH
 */
public class Dcos extends BaseClass {
    
    public Dcos(WebDriver driver) {
        super(driver);
    }
    
    @FindBy(how=How.ID , using = "username")
    public static WebElement inputUsername;
    
    @FindBy(how=How.ID , using = "password")
    public static WebElement inputPassword;
    
    @FindBy(how=How.ID , using = "login-button")
    public static  WebElement btnLogin;
    
    @FindBy(how=How.CLASS_NAME , using = "user-description")
    public static WebElement optUserProfile;
    
    @FindBy(how=How.LINK_TEXT , using = "Sign Out")
    public static WebElement btnSingOut;
    
    @FindBy(how=How.LINK_TEXT , using = "Services")
    public static WebElement optServices;
    
    @FindBy(how=How.LINK_TEXT , using = "intelligence")
    public static WebElement linkIntelligence;
    
    @FindBy(how=How.LINK_TEXT , using = "inintc")
    public static WebElement linkInintc;
    
    @FindBy(how=How.LINK_TEXT , using = "inmdco")
    public static WebElement linkInmdco;
    
    @FindBy(how=How.LINK_TEXT , using = "analytic")
    public static WebElement linkAnalytic;
}
