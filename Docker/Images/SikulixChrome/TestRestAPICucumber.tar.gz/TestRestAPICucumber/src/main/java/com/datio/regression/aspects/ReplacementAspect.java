package com.datio.regression.aspects;

import com.datio.regression.exceptions.NonReplaceableException;
import gherkin.formatter.model.*;
import org.aspectj.lang.annotation.*;

import gherkin.I18n;
import gherkin.formatter.Reporter;

import java.lang.reflect.Field;
import com.datio.regression.util.ThreadProperty;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;

@Aspect
public class ReplacementAspect {

    private final Logger LOGGER = Logger.getLogger(this.getClass().getCanonicalName());

    @Pointcut("execution (public void cucumber.runtime.Runtime.runStep(..)) && "
            + "args (featurePath, step, reporter, i18n)")
    protected void replacementStar(String featurePath, Step step, Reporter reporter, I18n i18n) {
    }

    @Before(value = "replacementStar(featurePath, step, reporter, i18n)")
    public void beforeReplacementStar(JoinPoint jp, String featurePath, Step step, Reporter reporter, I18n i18n) throws Throwable {

        String stepName = step.getName();
        String newName = replacedElement(stepName, jp);
        if (!stepName.equals(newName)) {

            Class current = step.getClass();
            Field field = null;

            do {
                try {
                    field = current.getDeclaredField("name");
                } catch (Exception e) {
                }
            } while ((current = current.getSuperclass()) != null);

            field.setAccessible(true);
            field.set(step, newName);
        }

        LOGGER.log(Level.FINE, step.getKeyword()+ step.getName());
    }

    protected String replacedElement(String el, JoinPoint jp) throws NonReplaceableException{
        if (el.contains("${")) {
            el = replaceReflectionPlaceholders(el, jp);
        }
        return el;
    }

    protected String replaceReflectionPlaceholders(String element, JoinPoint pjp) throws NonReplaceableException{
        String newVal = element;
        while (newVal.contains("${")) {
            String placeholder = newVal.substring(newVal.indexOf("${"),
                    newVal.indexOf("}", newVal.indexOf("${")) + 1);
            String attribute = placeholder.substring(2, placeholder.length() - 1);
            // we want to use value previously saved
            String prop = ThreadProperty.get(attribute);
            if (prop == null) {
                LOGGER.log(Level.WARNING, element.concat(" -> ").concat(attribute).concat(" local var has not been saved correctly previously."));
                throw new NonReplaceableException("Unreplaceable placeholder: " + placeholder);
            } else {
                newVal = newVal.replace(placeholder, prop);
            }
        }

        return newVal;
    }
}
