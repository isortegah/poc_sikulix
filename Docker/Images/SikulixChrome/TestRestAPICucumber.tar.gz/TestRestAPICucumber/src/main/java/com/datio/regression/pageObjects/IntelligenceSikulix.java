package com.datio.regression.pageObjects;

import org.sikuli.script.Screen;

public class IntelligenceSikulix {

    private static Screen screen = null;



}
