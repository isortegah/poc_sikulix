package com.datio.regression.stepdefs;

import com.datio.regression.util.ThreadProperty;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 *
 * @author ISORTEGAH|
 */
public class Hooks {
    
    public static RemoteWebDriver driver = null;
    private DesiredCapabilities capabilities;
    
    @Before("@Web")
    public void beforeScenario() throws MalformedURLException{
        String browser = ThreadProperty.get("BROWSER");
        String urlHub = ThreadProperty.get("HUB_URL");
        if (browser.equals("CHROME")){
            File modifyHeaders = new File(System.getProperty("user.dir")
                +"/src/test/resources/Modify-Headers-for-Google-Chrome_v2.0.7.crx");
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--start-maximized");
            options.addExtensions(modifyHeaders);
                capabilities = new DesiredCapabilities();
            capabilities.setBrowserName("chrome");
            capabilities.setAcceptInsecureCerts(true);
            capabilities.setPlatform(org.openqa.selenium.Platform.ANY);
            capabilities.setCapability(ChromeOptions.CAPABILITY, options);
            driver = new RemoteWebDriver( new URL(urlHub) , capabilities);
            driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        }
    }

    @Before("@WebSikulix")
    public void beforeScenarioSikulix(){
        System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "//src//test//resources//drivers/chromedriver");
        File modifyHeaders = new File(System.getProperty("user.dir")
                +"/src/test/resources/Modify-Headers-for-Google-Chrome_v2.0.7.crx");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addExtensions(modifyHeaders);
        driver = new ChromeDriver(options);
    }
    
    @After("@Web,@WebSikulix")
    public void afterScenario(){
        driver.close();
    }
}
