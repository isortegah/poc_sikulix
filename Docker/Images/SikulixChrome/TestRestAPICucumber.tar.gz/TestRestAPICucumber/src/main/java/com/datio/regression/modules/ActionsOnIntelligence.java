package com.datio.regression.modules;

import com.datio.regression.pageObjects.Intelligence;

/**
 *
 * @author ISORTEGAH
 */
public class ActionsOnIntelligence {
    
    public static void login (){
        Intelligence.btnStart.click();
    }
    
    public static void logout (){
        Intelligence.btnLogout.click();
    }
}
