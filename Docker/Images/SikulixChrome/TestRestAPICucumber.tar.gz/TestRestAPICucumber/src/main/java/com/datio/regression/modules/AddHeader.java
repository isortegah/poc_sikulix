package com.datio.regression.modules;

import com.datio.regression.pageObjects.ModifyHeaders;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

/**
 *
 * @author ISORTEGAH
 */
public class AddHeader {

    public static void Execute(RemoteWebDriver driver, String key, String header) {
        ModifyHeaders.btnStart.click();
        ModifyHeaders.btnNew.click();        
        Select select = new Select(ModifyHeaders.actionDropDown);
        select.selectByVisibleText("Add");
        ModifyHeaders.inputName.sendKeys( key );
        ModifyHeaders.inputValue.sendKeys( header );
        ModifyHeaders.btnSave.click();
        ModifyHeaders.enableHeader.click();
    }
}
