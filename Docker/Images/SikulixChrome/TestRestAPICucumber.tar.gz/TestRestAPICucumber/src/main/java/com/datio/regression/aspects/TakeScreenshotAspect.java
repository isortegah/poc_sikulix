package com.datio.regression.aspects;

import com.datio.regression.stepdefs.Hooks;
import com.datio.regression.util.ThreadProperty;
import cucumber.runtime.Runtime;
import gherkin.I18n;
import gherkin.formatter.Formatter;
import gherkin.formatter.Reporter;
import gherkin.formatter.model.*;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.codehaus.plexus.util.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 *
 * @author ISORTEGAH
 */
@Aspect
public class TakeScreenshotAspect {

    private final Logger LOGGER = Logger.getLogger(this.getClass().getCanonicalName());
    private String scenarioName = null;
    private Boolean execute = false;
    private List<String> tagsValids = null;
    private List<ScenarioRun> scenarios = new ArrayList<ScenarioRun>();
    private int numStep = 0 ;
    private String statusRunStep;

    
    @Pointcut("execution (public void cucumber.runtime.Runtime.runStep(..)) && "
            + "args (featurePath, step, reporter, i18n)")
    protected void takeScreenshotStar(String featurePath, Step step, Reporter reporter, I18n i18n) {

    }

    @After(value = "takeScreenshotStar(featurePath, step, reporter, i18n)")
    public void afterTakeScreenshotStar(JoinPoint jp, String featurePath, Step step, Reporter reporter, I18n i18n) throws Throwable {
        if(isExecute() && isStatusRunStepValid()){
            RemoteWebDriver driver = Hooks.driver;
            String stepName = step.getName().replace("/" ,"-");
            String execution = new SimpleDateFormat("MM-dd-yyyy_HH-mm").format(new GregorianCalendar().getTime())
                    +"/";
            File imageFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String imageFileName = scenarioName
                    + "/" + execution + Integer.toString(numStep) + "." + stepName + "-"
                    + new SimpleDateFormat("MM-dd-yyyy_HH-mm-ss-SS").format(
                            new GregorianCalendar().getTime()) + ".png";
            File pathScreenShot = new File(System.getProperty("user.dir") + "//screenshots//" + imageFileName);
            FileUtils.copyFile(imageFile, pathScreenShot);
            numStep++;
        }
    }

    @Pointcut("execution (public void cucumber.runtime.model.CucumberFeature.scenario(..)) && "
            + "args(scenario)")
    protected void scenario(Scenario scenario) {}

    @Before(value="scenario(scenario)")
    public void beforeScenario(Scenario scenario){
        saveScenarioData(scenario);
        execute = false;
        scenarioName = scenario.getName();
    }

    @Pointcut("execution (public void cucumber.runtime.model.CucumberFeature.scenarioOutline(..)) && "
            + "args(scenarioOutline)")
    protected void scenarioOutline(ScenarioOutline scenarioOutline) {}

    @Before(value="scenarioOutline(scenarioOutline)")
    public void beforeScenarioOutline(ScenarioOutline scenarioOutline){
        saveScenarioOutlineData(scenarioOutline);
        execute = false;
        scenarioName = scenarioOutline.getName();
    }

    public TakeScreenshotAspect(){
        tagsValids = Arrays.asList("@Web");
    }

    private Boolean isExecute(){
        return execute;
    }

    private void saveScenarioData(Scenario scenario){
        ScenarioRun scenarioRun = new ScenarioRun();
        List<String> tagsScenario = new ArrayList<String>();
        scenarioRun.setScenarioName(scenario.getName());

        scenario.getTags().forEach((tag)->{
            tagsScenario.add(tag.getName());
        });
        scenarioRun.setTags(tagsScenario);
        scenarios.add(scenarioRun);
    }

    private void saveScenarioOutlineData(ScenarioOutline scenarioOutline){
        ScenarioRun scenarioRun = new ScenarioRun();
        List<String> tagsScenario = new ArrayList<String>();
        scenarioRun.setScenarioName(scenarioOutline.getName());

        scenarioOutline.getTags().forEach((tag)->{
            tagsScenario.add(tag.getName());
        });
        scenarioRun.setTags(tagsScenario);
        scenarios.add(scenarioRun);
    }

    @Pointcut("execution (public void cucumber.runtime.model.CucumberTagStatement.run(..))")
    protected void runScenario() {}

    @Before( value = "runScenario()")
    public void beforeRunScenario(){
        if( scenarios.size()>0 ) {
            scenarioName = scenarios.get(0).getScenarioName();
            verifyExistenceTagsValids(scenarios.get(0).getTags());
        }
        numStep = 1;

    }

    @After( value = "runScenario()")
    public void afterRunScenario(){
        if( scenarios.size() > 0 ){
            scenarios.remove(0);
            execute = false;
        }
    }
    
    private void verifyExistenceTagsValids(List<String> tags) {
        tags.forEach((tag) -> {
            tagsValids.forEach((tagValid) ->{
                if(tagValid.equals(tag))
                    execute=true;
            });
        });
    }

    @Pointcut("execution (void cucumber.runtime.ScenarioImpl.add(..)) && args(result)")
    protected void scenarioImpl(Result result){}

    @Before( value ="scenarioImpl(result)")
    public void beforeScenarioImpl(Result result){
        statusRunStep = result.getStatus();
    }

    private Boolean isStatusRunStepValid(){
        switch (ThreadProperty.get("SCREENSHOT")){
            case "ALL":
                return true;
            case "FAIL":
                return !statusRunStep.equals("passed");
            case "PASS":
                return statusRunStep.equals("passed");
            default:
                return false;
        }
    }

}
