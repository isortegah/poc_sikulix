package com.datio.regression.modules;

import com.datio.regression.pageObjects.Dcos;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 *
 * @author ISORTEGAH
 */
public class ActionsOnDcos {
    
    public static void login( RemoteWebDriver driver , String username 
            , String password) throws InterruptedException {
        Dcos.inputUsername.sendKeys( username );
        Dcos.inputPassword.sendKeys( password );
        Dcos.btnLogin.click();
        driver.switchTo().defaultContent();
    }
    
    public static void logOut ( RemoteWebDriver driver ){
        Dcos.optUserProfile.click();
        Dcos.btnSingOut.click();
        driver.switchTo().defaultContent();
    }
    
    public static void selectServices() {
        Dcos.optServices.click();
    }

    public static void selectFolder( String path) {
        String[] splitPath = path.split("/");
        Dcos.linkIntelligence.click();
        if (splitPath[2].equals("inmdco"))
            Dcos.linkInmdco.click();
        else
            Dcos.linkInintc.click();
        Dcos.linkAnalytic.click();
    }
    
    public static boolean isContainerPresent( RemoteWebDriver driver 
            ,  String username ) {
        String usrname = username.toLowerCase();
        return driver.findElementByPartialLinkText(usrname).isDisplayed();
    }
    
    public static boolean checkStatusContainer( RemoteWebDriver driver 
            , String username ) {
        String usrname = username.toLowerCase();
        String attr = driver.findElementByPartialLinkText(usrname)
                .getAttribute("data-reactid");
        String id = attr.substring(0, attr.length()-7) + "1";
        WebElement el = driver.findElement(
                By.cssSelector("td[data-reactid=\""+id+"\"]"));
        return el.getText().contains("Running");
    }
}