package com.datio.regression.pageObjects;

import org.sikuli.script.ImagePath;
import org.sikuli.script.Screen;

/**
 *
 * @author ISORTEGAH
 */
public class TestScreen {

    private static Screen instance = null;
    private static String imagePath = "src/test/resources/images";

    protected TestScreen() {
        // Exists only to defeat instantiation.
    }
    public static Screen getInstance() {
        if(instance == null) {
            instance = getScreen();
        }
        return instance;
    }

    private static Screen getScreen () {
        Screen s = new Screen();
        ImagePath.add(imagePath);
        System.out.println(Screen.getNumberScreens());
        if(Screen.getNumberScreens() > 1 ){
            return new Screen(1);
        }
        return s;
    }
}